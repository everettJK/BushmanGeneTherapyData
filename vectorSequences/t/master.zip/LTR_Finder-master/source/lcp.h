/*
* =====================================================================================
* 
*       Filename:  lcp.h
* 
*    Description:  
* 
*        Version:  1.0
*        Created:  2006年10月10日 11时09分57秒 CST
*       Revision:  none
*       Compiler:  gcc
* 
*         Author:   (), 
*        Company:  
* 
* =====================================================================================
*/

typedef unsigned char uchar;

int *lcp(const int *a, const char *s, int n);
int lcpa(const int *a, const char *s, int *b, int n);
